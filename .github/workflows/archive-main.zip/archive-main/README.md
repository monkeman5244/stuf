# Silvereen Games Archive

All assets to Silvereen Games open source projects

## Installation

This site can be accessed from https://archive.silvereen.net but if you want to deploy on your own system then:

### Test

`npm run dev`

### For production builds

`npm run build`

then

`node build`
