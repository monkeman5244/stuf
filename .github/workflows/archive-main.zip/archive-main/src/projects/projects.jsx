const games = [
  {
    name: "Ball Dodge",
    image: "https://moonlight.silvereen.net/src/static/icons/ball-dodge.png",
    link: "https://moonlight.silvereen.net/src/static/games/ball-dodge/index.html",
    description: "A simple game where you have to dodge the balls.",
  },
];
